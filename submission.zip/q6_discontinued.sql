SELECT ProductName, CompanyName,ContactName 
FROM (
	SELECT * 
	from Product join OrderDetail join [Order] join Customer join (select min(OrderDate) as min_date , ProductName
	from (SELECT * 
		from Product join OrderDetail join [Order] join Customer 
		on Product.Id = ProductId AND OrderId = [Order].Id AND CustomerId = Customer.Id AND Discontinued = 1 Order by ProductName)
	GROUP BY ProductName) as min_table
	on Product.Id = ProductId AND OrderId = [Order].Id AND CustomerId = Customer.Id AND Discontinued = 1 AND min_table.ProductName = Product.ProductName Order by ProductName)
where OrderDate = min_date
;