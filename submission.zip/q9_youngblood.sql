select RegionDescription,FirstName,LastName,BirthDate 
from
    (select ROW_NUMBER() 
        over(
            PARTITION by RegionDescription Order by BirthDate DESC
            ) as row_num, *  from Region 
        join Territory join EmployeeTerritory join Employee 
        on Employee.Id = EmployeeId 
            AND TerritoryId = Territory.Id 
            AND RegionId = Region.Id)T  
where T.row_num = 1 ;
order by RegionId;